# SpeakUp app (installable)

This folder is a Progressive Web App (PWA). Put all files on any HTTPS website, for example GitHub Pages, and it can be installed like an app.

## Put it online with GitHub Pages
1. Create a public repository on github.com.
2. Upload ALL files in this folder (index.html, manifest.webmanifest, sw.js and the icon files).
3. Settings > Pages > Deploy from a branch > main / (root) > Save.
4. Open https://YOUR-USERNAME.github.io/REPO-NAME/ on your phone in Chrome.

## Install on Android
Chrome menu (three dots) > Install app (or Add to Home screen). An "Install app" button also appears at the top of the page.

## Install on iPhone
Open the site in Safari > Share button > Add to Home Screen.

## Install on a computer
Chrome or Edge address bar > Install icon.

## Make an Android APK (optional)
Go to https://www.pwabuilder.com, enter your site's address, and download the Android package.
